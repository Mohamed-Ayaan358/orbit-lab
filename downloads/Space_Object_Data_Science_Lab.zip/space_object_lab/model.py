"""Teaching model: synthetic populations, not MOCAT or operational orbit prediction."""
import numpy as np
import pandas as pd

DEFAULTS=dict(years=30,runs=500,initial_satellites=600,initial_debris=1400,
              retire_probability=0.08,decay_probability=0.02,fragments_per_collision=60)

def simulate(annual_launches=120,disposal=0.9,collision_coefficient=0.4,seed=20261027,**kwargs):
    """One-year source/sink steps. Coefficient units: events per million S*D pairs/year.

    Launches ~ Poisson(annual_launches).
    Retirement ~ Binomial(S, retire_probability).
    Failed disposal adds one derelict to the debris category.
    Debris removal ~ Binomial(D, decay_probability).
    Satellite-debris collisions ~ Poisson(kappa*S*D/1e6), capped by available
    objects. Each event removes one S and one D, then adds Poisson(60) fragments.
    Independence, homogeneous mixing, constant rates, and unit-year discretization
    are assumptions. There are no debris-debris collisions, orbital propagation,
    masses, avoidance maneuvers, or physical calibration.
    """
    cfg=DEFAULTS|kwargs
    assert annual_launches>=0 and 0<=disposal<=1 and collision_coefficient>=0
    rng=np.random.default_rng(seed);R,Y=cfg['runs'],cfg['years']
    S=np.zeros((R,Y+1),dtype=np.int64);D=S.copy();S[:,0]=cfg['initial_satellites'];D[:,0]=cfg['initial_debris']
    L=np.zeros_like(S);C=np.zeros_like(S);F=np.zeros_like(S);Removed=np.zeros_like(S)
    for t in range(1,Y+1):
        launch=rng.poisson(annual_launches,R)
        retired=rng.binomial(S[:,t-1],cfg['retire_probability'])
        failed=rng.binomial(retired,1-disposal)
        decayed=rng.binomial(D[:,t-1],cfg['decay_probability'])
        s=S[:,t-1]+launch-retired;d=D[:,t-1]-decayed+failed
        proposed=rng.poisson(collision_coefficient*s*d/1_000_000)
        collision=np.minimum(proposed,np.minimum(s,d))
        fragments=rng.poisson(collision*cfg['fragments_per_collision'])
        S[:,t]=s-collision;D[:,t]=d-collision+fragments
        L[:,t]=launch;C[:,t]=collision;F[:,t]=fragments;Removed[:,t]=decayed
    assert np.all(S>=0) and np.all(D>=0)
    return dict(satellites=S,debris=D,launches=L,collisions=C,fragments=F,decayed=Removed,config=cfg)

def records(sim,scenario_id,annual_launches,disposal,collision_coefficient):
    R,T=sim['debris'].shape
    df=pd.DataFrame({'scenario_id':scenario_id,'run':np.repeat(np.arange(R),T),
        'year':np.tile(np.arange(T),R),'annual_launches':annual_launches,
        'disposal_probability':disposal,'collision_coefficient':collision_coefficient})
    for name in ['satellites','debris','launches','collisions','fragments','decayed']:
        df[name]=sim[name].ravel()
    return df

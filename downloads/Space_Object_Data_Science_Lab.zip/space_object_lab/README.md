# Space-object data science lab

A working teaching prototype for studying how uncertain launches, disposal, and fragmentation can affect a synthetic debris population. The notebook includes executed figures and statistical results. All scenario data are simulated. The six-row CelesTrak sample is real catalog input included only to practice loading and inspecting a different source; it does not initialize the population model.

## Start here

Open `Space_Object_Data_Science_Lab.ipynb` in a Python notebook editor. Keep it in this folder so its relative data paths work. The saved outputs can be reviewed without running it.

To run the lessons, create a Python 3.12 environment, install `requirements.txt`, and select that environment as the notebook kernel. `generate_data.py` regenerates the synthetic dataset with fixed seeds. `model.py` contains the population model.

## Learning map

| Lesson | Question | Tools |
|---|---|---|
| Summaries | How much do possible year-30 populations vary? | pandas, NumPy, Seaborn |
| Poisson | What is the probability of at least 15 launches in a month? | NumPy, SciPy |
| Normal approximation | Why are sample averages less variable than individual counts? | NumPy, SciPy, Matplotlib |
| Simulation | How do disposal policies change the distribution of outcomes? | NumPy, quantiles, Matplotlib |
| Inference | What can 24 counts tell us about an unknown launch rate? | PyMC, ArviZ; exact SciPy validation |
| 3D | How can we display an orbital population schematically? | Matplotlib 3D; interactive view in the chat |
| Data engineering | How do we aggregate scenario output stored in partitions? | Parquet, pandas; optional Spark example |

## What the model assumes

There are initially 600 satellites and 1,400 debris/derelict objects. Each year uses Poisson launches, binomial satellite retirement (8%), disposal success, and debris removal (2%). A simplified collision intensity is `coefficient * satellites * debris / 1,000,000` per year. Collisions remove one satellite and one debris object, and add Poisson fragments with mean 60 per collision. These values are teaching assumptions, not measured or calibrated rates. Successful disposal removes retired satellites immediately. Failed disposal adds a derelict. No debris–debris collisions are modeled.

The 27 scenarios cross 3 launch rates, 3 disposal rates, and 3 collision coefficients. Each has 500 independent runs and 31 snapshots, giving 418,500 rows. Shaded bands describe simulation variability conditional on fixed assumptions. They do not include uncertainty in those assumptions. The Bayesian lesson instead estimates an unknown monthly launch rate from synthetic observations. A Normal approximation is applied to sample means, not asserted for debris counts.

The 3D positions are illustrative and independent of the population calculation. They are not propagated real orbits, and proximity in the picture is not a collision prediction. This model is not MOCAT-pySSEM.

## A graduate big data project

Suggested question: **How do launch growth and disposal policies affect the distribution of future debris populations under uncertain model assumptions?**

The delivered dataset is laptop scale. Simply adding charts or reading this file with Spark does not make it a big data project. A larger implementation would distribute independent scenario/run batches across Spark workers, write partitioned Parquet to shared object storage, validate each batch, aggregate quantiles and policy comparisons, and measure time and cost as the ensemble grows. Generate random streams from scenario and batch identifiers so parallel reruns are reproducible. Avoid collecting all runs on the driver. Partition at a sensible batch size to avoid many tiny files.

For a scientifically credible proposal, replace the teaching population model with a validated orbital-environment model, calibrate inputs, and compare historical hindcasts before interpreting policy outcomes. Real catalog histories and physical-property coverage require separate ingestion and quality checks. This notebook does not demonstrate a cluster benchmark or a calibrated forecast. Its optional Spark cell is disabled and was not executed.

## Sources

- CelesTrak catalog documentation: https://celestrak.org/NORAD/documentation/gp-data-formats.php
- SciPy Poisson distribution: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.poisson.html
- PyMC: https://www.pymc.io/projects/docs/en/stable/
- MOCAT-pySSEM, a possible later physics-model integration: https://github.com/ARCLab-MIT/pyssem

The included CelesTrak sample was retrieved on 2026-10-21. Catalog snapshots change; it is not a complete debris inventory. No authenticated ESA DISCOS data are included.

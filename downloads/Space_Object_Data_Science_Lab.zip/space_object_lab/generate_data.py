import sys,json,itertools,shutil
from pathlib import Path
import numpy as np,pandas as pd
from scipy import stats
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.resolve()))
from model import simulate,records,DEFAULTS
payload={'metadata':{'kind':'synthetic teaching simulation','seed':20261027,'runs':500,**DEFAULTS},'scenarios':{},'statistics':{}}
for i,(L,P,K) in enumerate(itertools.product([40,120,240],[0.6,0.9,0.99],[0.0,0.4,1.2])):
    sid=f'{L}_{P}_{K}';sim=simulate(L,P,K,seed=20261027+i)
    arr=sim['debris'];q=np.quantile(arr,[.025,.5,.975],axis=0)
    payload['scenarios'][sid]={'low':q[0].round(1).tolist(),'median':q[1].round(1).tolist(),'high':q[2].round(1).tolist(),
        'satellites':sim['satellites'][0].tolist(),'debris':arr[0].tolist(),'collisions':sim['collisions'][0].tolist(),
        'launches':sim['launches'][0].tolist(),'mean':round(float(arr[:,-1].mean()),1),
        'std':round(float(arr[:,-1].std(ddof=1)),1),'final_median':round(float(np.median(arr[:,-1])),1)}
    df=records(sim,sid,L,P,K)
    target=base/'data'/'ensemble'/f'scenario_id={sid}';target.mkdir(parents=True,exist_ok=True)
    df.drop(columns='scenario_id').to_parquet(target/'part-000.parquet',index=False)
    if sid=='120_0.9_0.4':
        df.to_csv(base/'data'/'baseline_simulations.csv',index=False)
for L in [40,120,240]:
    r=np.random.default_rng(1000+L);mu=L/12
    obs=r.poisson(mu,24);pd.DataFrame({'month':range(1,25),'launches':obs,'source':'synthetic'}).to_csv(base/'data'/f'monthly_launches_{L}.csv',index=False)
    counts=r.poisson(mu,2000);ks=np.arange(0,int(stats.poisson.ppf(.9999,mu))+1)
    freq=np.bincount(counts,minlength=len(ks))[:len(ks)]/len(counts)
    # CLT: independent 12-month sample means, not the debris population.
    means=r.poisson(mu,(2000,12)).mean(axis=1);hist,edges=np.histogram(means,bins=24,density=True)
    x=np.linspace(min(edges[0],mu-4*np.sqrt(mu/12)),max(edges[-1],mu+4*np.sqrt(mu/12)),160)
    alpha,beta=2+int(obs.sum()),.2+len(obs);post=stats.gamma(alpha,scale=1/beta)
    px=np.linspace(max(.0001,min(stats.gamma.ppf(.001,2,scale=5),post.ppf(.001))),max(stats.gamma.ppf(.999,2,scale=5),post.ppf(.999)),200)
    payload['statistics'][str(L)]={'mu':mu,'counts':[{'x':int(k),'observed':round(float(f),5),'theory':round(float(stats.poisson.pmf(k,mu)),5)} for k,f in zip(ks,freq)],
        'means':[{'x0':round(float(a),4),'x1':round(float(b),4),'y':round(float(h),5)} for a,b,h in zip(edges[:-1],edges[1:],hist)],
        'normal':[{'x':round(float(z),4),'y':round(float(stats.norm.pdf(z,mu,np.sqrt(mu/12))),5)} for z in x],
        'posterior':[{'x':round(float(z),4),'prior':round(float(stats.gamma.pdf(z,2,scale=5)),7),'posterior':round(float(post.pdf(z)),7)} for z in px],
        'ci':post.ppf([.025,.975]).round(3).tolist(),'posterior_mean':round(float(post.mean()),3),'observations':obs.tolist()}
(base/'lab_data.json').write_text(json.dumps(payload,separators=(',',':')))
if Path('work/celestrak_debris_sample.csv').exists():shutil.copy('work/celestrak_debris_sample.csv',base/'data'/'celestrak_sample_2026-10-21.csv')
print('scenarios',len(payload['scenarios']),'JSON bytes',(base/'lab_data.json').stat().st_size)
